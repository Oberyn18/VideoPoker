
public class PlacarJogador {

}
