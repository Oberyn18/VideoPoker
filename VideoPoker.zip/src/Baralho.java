/**
 * Esta classe representa um baralho de cartas.
 * Quer dizer, um conjunto de 52 cartas.
 * @author Oberyn
 *
 */
public class Baralho {
	/**
	 * Array de cartas, tudas formam parte de Baralho.
	 */
	private Carta[] cartas = new Carta[52];
	
	/**
	 * Este construtor preenche automaticamente o baralho de cartas.
	 */
	public Baralho(){
		
	}
	
	
}
